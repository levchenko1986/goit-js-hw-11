


// galleryListEl.insertAdjacentHTML('beforeend', galleryItemElements);



// let lightbox = new SimpleLightbox('.gallery a', {
//     captionsData: 'alt',
//     captionDelay: 250,
//     captionPosition: 'bottom',
// });
